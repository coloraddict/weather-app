import { DatetimePipe } from './datetime.pipe';

describe('DatetimePipe', () => {
  it('create an instance', () => {
    const pipe = new DatetimePipe();
    expect(pipe).toBeTruthy();
  });
});
